// JavaScript Document

var nRequired_nome = "Digite seu nome completo";
		var nRequired_email = "Digite um e-mail válido";
		var nRequired_cpf = "Digite um cpf válido";
		var nRequired_telefone = "Por favor, verifique o número digitado";
		var nRequired_numero_cartao = "Digite um número de cartão válido";
		var nRequired_nome_cartao = "Digite o nome completo do titular";
		var nRequired_data_cartao = "Digite uma data válida<br /><span>O ano deve ser preenchido com 4 dígitos</span>";
		var nRequired_cvv_cartao = "Digite um CVV válido";
		var nRequired_condicoes = "Aceite as condições antes de prosseguir";
	
		function ApenasTexto(event,cArr){
			// ALLOW CONTROLS SUCH AS BACKSPACE, TAB ETC.
			var arr = [8,9,16,17,20,32,35,36,37,38,39,40,45,46];

			if (cArr)
				arr = arr.concat(cArr);
			
			// ALLOW LETTERS
			for(var i = 65; i <= 90; i++)
				arr.push(i);

			// PREVENT DEFAULT IF NOT IN ARRAY
			if(jQuery.inArray(event.which, arr) === -1)
				event.preventDefault();
		}
		
		function DeclararValidacoes(){
			$("#frmCadastro").validate({
				errorClass: "error_message",
				errorElement: "p",
				groups: {
					card_month_year: "card_month card_year"
				},
				rules: {
					full_name: { required: true },
					email_addr: { required: true },
					cpf: { required: true },
					tel: { required: true },
					card_number: { required: true },
					card_name: { required: true },
					card_month: { required: true, number: true, min: 1 },
					card_year: { required: true, number: true, min: 1 },
					card_code: { required: true, number: true, min: 1 },
					rules: { required: true }
				},
				messages: {
					full_name: { required: nRequired_nome },
					email_addr: { required: nRequired_email },
					cpf: { required: nRequired_cpf },
					tel: { required: nRequired_telefone },
					card_number: { required: nRequired_numero_cartao },
					card_name: { required: nRequired_nome_cartao },
					card_month: { required: nRequired_data_cartao, min: nRequired_data_cartao },
					card_year: { required: nRequired_data_cartao, min: nRequired_data_cartao },
					card_code: { required: nRequired_cvv_cartao, min: nRequired_cvv_cartao },
					rules: { required: nRequired_condicoes, min: nRequired_condicoes }
				}
			});
		}
	
		$(document).ready(function() {
			$("#cpf").mask('000.000.000-00');
			$("#tel").mask('(00) 0000-0000');
			
			$("#card_month").mask('00');
			$("#card_year").mask('0000');
			$("#card_code").mask('000');
			
			$("#card_number").mask('0000 0000 0000 0000');
			
			$("#full_name").keydown(ApenasTexto);
			$("#card_name").keydown(ApenasTexto);
			$("#email_addr").keydown(function(e){ApenasTexto(e,[48,49,50,51,52,53,54,55,56,57,189,190]);});
			
			DeclararValidacoes();

			$("#btnSubmit").click(function(){
				if ($("#frmCadastro").valid())
					window.location.href = 'final.html';
			});
		});